from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone

from .forms import AnalyticsQueryForm, RunPipelineForm
from .models import PipelineRun
from .services import ANALYTICS_QUERIES, run_analytics_query, run_pipeline


def run_console(request):
    """Home page: trigger a pipeline run, see the result inline, browse recent runs."""
    result = None

    if request.method == "POST":
        form = RunPipelineForm(request.POST)
        if form.is_valid():
            cities = form.cleaned_data["resolved_cities"]
            days = form.cleaned_data["days"]
            dry_run = form.cleaned_data["dry_run"]

            run_record = PipelineRun.objects.create(
                cities_requested=cities,
                days_back=days,
                dry_run=dry_run,
                status="running",
            )

            result = run_pipeline(cities=cities, days=days, dry_run=dry_run)

            run_record.finished_at = timezone.now()
            run_record.cities_succeeded = result.cities_succeeded
            run_record.start_date = result.start_date
            run_record.end_date = result.end_date
            run_record.rows_fetched = result.rows_fetched
            run_record.rows_transformed = result.rows_transformed
            run_record.rows_loaded = result.rows_loaded
            run_record.status = result.status
            run_record.error_message = result.error_message
            run_record.save()

            if result.status == "success":
                messages.success(request, f"Run #{run_record.pk} completed successfully.")
            elif result.status == "partial":
                messages.warning(request, f"Run #{run_record.pk} completed with warnings.")
            else:
                messages.error(request, f"Run #{run_record.pk} failed.")
    else:
        form = RunPipelineForm()

    recent_runs = PipelineRun.objects.all()[:8]

    return render(
        request,
        "dashboard/run_console.html",
        {
            "form": form,
            "result": result,
            "recent_runs": recent_runs,
        },
    )


def run_history(request):
    runs = PipelineRun.objects.all()
    return render(request, "dashboard/run_history.html", {"runs": runs})


def run_detail(request, pk):
    run = get_object_or_404(PipelineRun, pk=pk)
    return render(request, "dashboard/run_detail.html", {"run": run})


def analytics(request):
    """Pick and run one of the canned Queries.sql-equivalent reports against BigQuery."""
    choices = [(key, spec["label"]) for key, spec in ANALYTICS_QUERIES.items()]
    selected_key = request.GET.get("query") or request.POST.get("query")
    form = AnalyticsQueryForm(query_choices=choices, initial={"query": selected_key})

    analytics_result = None
    selected_spec = None
    if selected_key and selected_key in ANALYTICS_QUERIES:
        selected_spec = ANALYTICS_QUERIES[selected_key]
        analytics_result = run_analytics_query(selected_key)

    return render(
        request,
        "dashboard/analytics.html",
        {
            "form": form,
            "selected_key": selected_key,
            "selected_spec": selected_spec,
            "result": analytics_result,
        },
    )
