from django import template

register = template.Library()


@register.filter
def get_item(mapping, key):
    """Look up ``key`` in a dict from a template (row|get_item:col)."""
    if mapping is None:
        return None
    value = mapping.get(key)
    return value if value not in (None, "") else "—"
