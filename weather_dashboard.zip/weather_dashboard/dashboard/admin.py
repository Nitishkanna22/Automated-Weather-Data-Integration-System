from django.contrib import admin

from .models import PipelineRun


@admin.register(PipelineRun)
class PipelineRunAdmin(admin.ModelAdmin):
    list_display = ("id", "started_at", "status", "dry_run", "rows_fetched", "rows_loaded")
    list_filter = ("status", "dry_run")
    readonly_fields = [f.name for f in PipelineRun._meta.fields]
