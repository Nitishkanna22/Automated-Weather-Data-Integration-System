from django.db import models


class PipelineRun(models.Model):
    """
    A local record of one pipeline execution triggered from the web UI.

    This is intentionally separate from the actual weather data, which
    lives in BigQuery (hourly_observations, loaded by Loader.py). This
    table only tracks *runs* — what was requested, what happened, and
    whether it succeeded — so the console can show a run history even
    when BigQuery access isn't configured (e.g. during a dry run).
    """

    STATUS_CHOICES = [
        ("running", "Running"),
        ("success", "Success"),
        ("partial", "Partial success"),
        ("failed", "Failed"),
    ]

    started_at = models.DateTimeField(auto_now_add=True)
    finished_at = models.DateTimeField(null=True, blank=True)

    cities_requested = models.JSONField(default=list)
    cities_succeeded = models.JSONField(default=list)
    days_back = models.PositiveIntegerField()
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)

    dry_run = models.BooleanField(default=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default="running")

    rows_fetched = models.PositiveIntegerField(default=0)
    rows_transformed = models.PositiveIntegerField(default=0)
    rows_loaded = models.PositiveIntegerField(default=0)

    error_message = models.TextField(blank=True, default="")

    class Meta:
        ordering = ["-started_at"]

    def __str__(self) -> str:
        return f"Run #{self.pk} — {', '.join(self.cities_requested)} ({self.status})"

    @property
    def duration_seconds(self) -> float | None:
        if not self.finished_at:
            return None
        return (self.finished_at - self.started_at).total_seconds()
