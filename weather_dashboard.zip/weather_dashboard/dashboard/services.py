"""
services.py
------------
The only place in the Django app that talks to the existing pipeline
modules (Fetcher, Transformer, Loader) and to BigQuery for analytics.
Views stay thin and call into here; nothing here renders HTML.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from typing import Any

from django.conf import settings

from Config import (
    BIGQUERY_DATASET_ID,
    BIGQUERY_PROJECT_ID,
    BIGQUERY_TABLE_ID,
)
from Fetcher import fetch_weather_for_cities
from Transformer import transform_weather_data

logger = logging.getLogger(__name__)

FULL_TABLE = f"`{BIGQUERY_PROJECT_ID}.{BIGQUERY_DATASET_ID}.{BIGQUERY_TABLE_ID}`"


@dataclass
class PipelineRunResult:
    cities_requested: list[str]
    cities_succeeded: list[str]
    start_date: date
    end_date: date
    dry_run: bool
    rows_fetched: int = 0
    rows_transformed: int = 0
    rows_loaded: int = 0
    preview_columns: list[str] = field(default_factory=list)
    preview_rows: list[dict[str, Any]] = field(default_factory=list)
    status: str = "success"
    error_message: str = ""


def run_pipeline(cities: list[str], days: int, dry_run: bool, preview_limit: int = 50) -> PipelineRunResult:
    """
    Runs exactly the same three steps Pipeline.py runs (fetch → transform →
    load), and returns a small, template-friendly summary. Never raises for
    ordinary partial failures (e.g. one bad city name); those show up as
    status="partial" with an explanatory message instead.
    """
    end_date = datetime.now(timezone.utc).date()
    start_date = end_date - timedelta(days=days)

    result = PipelineRunResult(
        cities_requested=cities,
        cities_succeeded=[],
        start_date=start_date,
        end_date=end_date,
        dry_run=dry_run,
    )

    try:
        raw_records = fetch_weather_for_cities(cities, start_date, end_date)
    except Exception as exc:  # network / library errors from Fetcher
        logger.exception("Fetch step raised unexpectedly")
        result.status = "failed"
        result.error_message = f"Fetching weather data failed: {exc}"
        return result

    if not raw_records:
        result.status = "failed"
        result.error_message = (
            "No data was fetched for any requested city. Check city spelling "
            "and network access to the Open-Meteo API."
        )
        return result

    result.rows_fetched = len(raw_records)
    result.cities_succeeded = sorted({r["city"] for r in raw_records})
    if set(result.cities_succeeded) != {c for c in cities}:
        result.status = "partial"

    df = transform_weather_data(raw_records)
    result.rows_transformed = len(df)

    if not df.empty:
        preview_df = df.head(preview_limit)
        result.preview_columns = list(preview_df.columns)
        result.preview_rows = preview_df.astype(object).where(preview_df.notnull(), None).to_dict(orient="records")

    if dry_run:
        return result

    # Import here (not at module load time) so the whole app doesn't hard-fail
    # to start up in environments without google-cloud-bigquery configured.
    from Loader import load_to_bigquery

    try:
        load_to_bigquery(
            df=df,
            project_id=BIGQUERY_PROJECT_ID,
            dataset_id=BIGQUERY_DATASET_ID,
            table_id=BIGQUERY_TABLE_ID,
        )
        result.rows_loaded = len(df)
    except Exception as exc:
        logger.exception("BigQuery load step failed")
        result.status = "partial" if result.status != "failed" else "failed"
        result.error_message = (result.error_message + " " if result.error_message else "") + (
            f"BigQuery load failed: {exc}"
        )

    return result


# ── Analytics (reads from BigQuery via Queries.sql equivalents) ────────────

ANALYTICS_QUERIES: dict[str, dict[str, str]] = {
    "daily_summary": {
        "label": "Daily temperature summary (last 7 days)",
        "description": "How hot/cold was each city, per day.",
        "sql": f"""
            SELECT
                city, date,
                ROUND(AVG(temperature_c), 2)          AS avg_temp_c,
                ROUND(MIN(temperature_c), 2)          AS min_temp_c,
                ROUND(MAX(temperature_c), 2)          AS max_temp_c,
                ROUND(AVG(apparent_temperature_c), 2) AS avg_feels_like_c,
                ROUND(AVG(relative_humidity_pct), 1)  AS avg_humidity_pct,
                ROUND(SUM(precipitation), 2)          AS total_precipitation_mm,
                COUNTIF(is_rainy_hour)                AS rainy_hours,
                ROUND(AVG(windspeed_kmh), 1)          AS avg_windspeed_kmh
            FROM {FULL_TABLE}
            WHERE date >= DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY)
            GROUP BY city, date
            ORDER BY date DESC, city
        """,
    },
    "hottest_hours": {
        "label": "Hottest hours (top 20)",
        "description": "Peak heat periods across all cities.",
        "sql": f"""
            SELECT city, timestamp, temperature_c, apparent_temperature_c,
                   feels_like_delta, heat_index_category, relative_humidity_pct
            FROM {FULL_TABLE}
            ORDER BY apparent_temperature_c DESC
            LIMIT 20
        """,
    },
    "heat_index_distribution": {
        "label": "Heat index category distribution",
        "description": "Comfort conditions at a glance, by city.",
        "sql": f"""
            SELECT city, heat_index_category, COUNT(*) AS hour_count,
                   ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (PARTITION BY city), 1) AS pct_of_hours
            FROM {FULL_TABLE}
            GROUP BY city, heat_index_category
            ORDER BY city, hour_count DESC
        """,
    },
    "hourly_pattern": {
        "label": "Average temperature by hour-of-day",
        "description": "Which hours run hottest, per city.",
        "sql": f"""
            SELECT city, hour_of_day,
                   ROUND(AVG(temperature_c), 2) AS avg_temp_c,
                   ROUND(AVG(relative_humidity_pct), 1) AS avg_humidity_pct,
                   ROUND(AVG(windspeed_kmh), 1) AS avg_windspeed_kmh
            FROM {FULL_TABLE}
            GROUP BY city, hour_of_day
            ORDER BY city, hour_of_day
        """,
    },
    "rainfall_ranking": {
        "label": "Cities ranked by total rainfall",
        "description": "Which city got the most rain in the period.",
        "sql": f"""
            SELECT city, ROUND(SUM(precipitation), 2) AS total_rain_mm,
                   COUNTIF(is_rainy_hour) AS rainy_hours, COUNT(*) AS total_hours,
                   ROUND(COUNTIF(is_rainy_hour) * 100.0 / COUNT(*), 1) AS rainy_hour_pct
            FROM {FULL_TABLE}
            GROUP BY city
            ORDER BY total_rain_mm DESC
        """,
    },
    "common_conditions": {
        "label": "Most common weather conditions",
        "description": "What type of weather dominated, per city.",
        "sql": f"""
            SELECT city, weather_description, COUNT(*) AS hours,
                   ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (PARTITION BY city), 1) AS pct
            FROM {FULL_TABLE}
            GROUP BY city, weather_description
            ORDER BY city, hours DESC
        """,
    },
    "duplicate_check": {
        "label": "Duplicate city + timestamp check",
        "description": "Data quality check after multiple pipeline runs.",
        "sql": f"""
            SELECT city, timestamp, COUNT(*) AS row_count
            FROM {FULL_TABLE}
            GROUP BY city, timestamp
            HAVING COUNT(*) > 1
            ORDER BY row_count DESC
        """,
    },
}


@dataclass
class AnalyticsResult:
    columns: list[str] = field(default_factory=list)
    rows: list[dict[str, Any]] = field(default_factory=list)
    error_message: str = ""


def run_analytics_query(query_key: str) -> AnalyticsResult:
    """Runs one of ANALYTICS_QUERIES against BigQuery and returns rows."""
    spec = ANALYTICS_QUERIES.get(query_key)
    if spec is None:
        return AnalyticsResult(error_message=f"Unknown query: {query_key}")

    try:
        from google.cloud import bigquery
    except ImportError:
        return AnalyticsResult(
            error_message="google-cloud-bigquery isn't installed in this environment."
        )

    try:
        client = bigquery.Client(project=BIGQUERY_PROJECT_ID)
        job = client.query(spec["sql"])
        rows = [dict(row.items()) for row in job.result()]
    except Exception as exc:
        logger.exception("Analytics query failed: %s", query_key)
        return AnalyticsResult(error_message=str(exc))

    columns = list(rows[0].keys()) if rows else []
    return AnalyticsResult(columns=columns, rows=rows)
