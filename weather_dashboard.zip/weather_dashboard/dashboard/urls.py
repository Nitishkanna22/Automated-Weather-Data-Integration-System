from django.urls import path

from . import views

app_name = "dashboard"

urlpatterns = [
    path("", views.run_console, name="run_console"),
    path("runs/", views.run_history, name="run_history"),
    path("runs/<int:pk>/", views.run_detail, name="run_detail"),
    path("analytics/", views.analytics, name="analytics"),
]
