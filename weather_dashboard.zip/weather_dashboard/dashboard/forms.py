from django import forms
from django.conf import settings

from Config import CITIES, DEFAULT_DAYS_BACK


class RunPipelineForm(forms.Form):
    """
    Drives Fetcher.fetch_weather_for_cities → Transformer.transform_weather_data
    → (optionally) Loader.load_to_bigquery, using the same defaults defined
    in Config.py.
    """

    cities = forms.MultipleChoiceField(
        choices=[(c, c) for c in CITIES],
        widget=forms.CheckboxSelectMultiple,
        required=False,
        help_text="Pulled from Config.CITIES. Leave all unchecked to use every configured city.",
    )
    extra_cities = forms.CharField(
        required=False,
        label="Additional cities",
        widget=forms.TextInput(attrs={"placeholder": "e.g. Kolkata, Pune"}),
        help_text="Comma-separated city names not already in the list above.",
    )
    days = forms.IntegerField(
        min_value=1,
        max_value=settings.PIPELINE_MAX_DAYS,
        initial=DEFAULT_DAYS_BACK,
        label="Days back",
        help_text=f"How many past days of hourly data to fetch (max {settings.PIPELINE_MAX_DAYS}).",
    )
    dry_run = forms.BooleanField(
        required=False,
        initial=True,
        label="Dry run (skip BigQuery load)",
        help_text="Fetch and transform only. Uncheck to load into BigQuery via Loader.py.",
    )

    def clean(self):
        cleaned = super().clean()
        selected = list(cleaned.get("cities") or [])
        extra_raw = cleaned.get("extra_cities") or ""
        extra = [c.strip() for c in extra_raw.split(",") if c.strip()]

        combined = selected + [c for c in extra if c not in selected]
        if not combined:
            combined = list(CITIES)

        if len(combined) > settings.PIPELINE_MAX_CITIES:
            raise forms.ValidationError(
                f"Too many cities requested ({len(combined)}). "
                f"Limit is {settings.PIPELINE_MAX_CITIES} per run."
            )

        cleaned["resolved_cities"] = combined
        return cleaned


class AnalyticsQueryForm(forms.Form):
    """Lets the user pick which canned query from Queries.sql to run."""

    query = forms.ChoiceField(choices=[], widget=forms.RadioSelect)

    def __init__(self, *args, query_choices=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["query"].choices = query_choices or []
